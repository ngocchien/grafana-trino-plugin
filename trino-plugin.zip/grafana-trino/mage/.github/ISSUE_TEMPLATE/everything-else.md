---
name: Everything Else
about: An issue that isn't a bug or a feature
title: ''
labels: ''
assignees: ''

---

If you have a question about how to use mage or any kind of discussion rather than something that is literally a bug report or feature request, consider heading on over to Mage's [Discussion](https://github.com/magefile/mage/discussions) area of github. That's your best bet for finding answers and helping other people who have the same question you have.
