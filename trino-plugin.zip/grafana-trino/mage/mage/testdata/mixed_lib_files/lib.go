// Some points here... we have a different package name for the non-mage code,
// and we need to make sure that we handle that.  We also have a duplicate
// funciotn name between the mage code and the non-mage code. That should also
// work correctly.

package lib

func Build() {]}
