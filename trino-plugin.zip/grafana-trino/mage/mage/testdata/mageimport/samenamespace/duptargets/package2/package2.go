package package2

import "fmt"

func Build() {
	fmt.Println("build")
}
