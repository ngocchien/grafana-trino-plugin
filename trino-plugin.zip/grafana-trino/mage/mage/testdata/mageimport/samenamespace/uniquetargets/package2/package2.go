package package2

import "fmt"

func Build2() {
	fmt.Println("build")
}
