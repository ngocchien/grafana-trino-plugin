package package1

import "fmt"

func Build1() {
	fmt.Println("build")
}
