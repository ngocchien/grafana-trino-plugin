// +build mage

package main

//mage:import
import _ "github.com/magefile/mage/mage/testdata/mageimport/oneline/other"
