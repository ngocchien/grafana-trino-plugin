package main

func foo() {}
