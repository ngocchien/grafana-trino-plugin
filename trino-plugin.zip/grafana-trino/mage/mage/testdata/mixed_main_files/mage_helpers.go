//+build mage

package main

func foo() {}
