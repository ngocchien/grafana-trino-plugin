+++
title = "{{ replace .TranslationBaseName "-" " " | title }}"
date = {{ .Date }}
type = "post"
author = "Nate Finch"
authorLink = "https://twitter.com/natethefinch"
draft = true
+++

